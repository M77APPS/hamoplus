package com.example.data

import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query

@Serializable
data class SafeBrowsingRequest(
    val client: ClientInfo,
    val threatInfo: ThreatInfo
)

@Serializable
data class ClientInfo(
    val clientId: String,
    val clientVersion: String
)

@Serializable
data class ThreatInfo(
    val threatTypes: List<String>,
    val platformTypes: List<String>,
    val threatEntryTypes: List<String>,
    val threatEntries: List<ThreatEntry>
)

@Serializable
data class ThreatEntry(
    val url: String
)

@Serializable
data class SafeBrowsingResponse(
    val matches: List<ThreatMatch>? = null
)

@Serializable
data class ThreatMatch(
    val threatType: String,
    val platformType: String,
    val threatEntryType: String,
    val threat: ThreatEntry,
    val cacheDuration: String = "300s"
)

interface SafeBrowsingApi {
    @POST("v4/threatMatches:find")
    suspend fun findThreatMatches(
        @Query("key") apiKey: String,
        @Body request: SafeBrowsingRequest
    ): SafeBrowsingResponse
}
