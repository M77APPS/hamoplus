package com.example.data

import com.example.BuildConfig
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val SAFE_BROWSING_BASE_URL = "https://safebrowsing.googleapis.com/"
    private const val VIRUS_TOTAL_BASE_URL = "https://www.virustotal.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val json = Json { 
        ignoreUnknownKeys = true
        coerceInputValues = true
    }

    val geminiService: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }

    val safeBrowsingService: SafeBrowsingApi by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(SAFE_BROWSING_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(SafeBrowsingApi::class.java)
    }

    val virusTotalService: VirusTotalApi by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(VIRUS_TOTAL_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(VirusTotalApi::class.java)
    }
}
