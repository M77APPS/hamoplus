package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultEntryDao {
    @Query("SELECT * FROM vault_entries ORDER BY timestamp DESC")
    fun getAllVaultEntries(): Flow<List<VaultEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultEntry(entry: VaultEntry)

    @Delete
    suspend fun deleteVaultEntry(entry: VaultEntry)

    @Query("DELETE FROM vault_entries")
    suspend fun clearVaultEntries()
}
