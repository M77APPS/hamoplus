package com.example.utils

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

object EnvironmentChecker {

    private const val TAG = "EnvironmentChecker"

    fun isEmulator(): Boolean {
        val fingerprint = Build.FINGERPRINT
        val model = Build.MODEL
        val manufacturer = Build.MANUFACTURER
        val hardware = Build.HARDWARE
        val product = Build.PRODUCT
        val brand = Build.BRAND
        val device = Build.DEVICE

        return fingerprint.startsWith("generic") ||
                fingerprint.startsWith("unknown") ||
                model.contains("google_sdk") ||
                model.contains("Emulator") ||
                model.contains("Android SDK built for x86") ||
                manufacturer.contains("Genymotion") ||
                brand.startsWith("generic") && device.startsWith("generic") ||
                "google_sdk" == product ||
                hardware.contains("goldfish") ||
                hardware.contains("ranchu") ||
                product.contains("sdk_gphone") ||
                model.contains("Subsystem for Android")
    }

    fun isRooted(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/system/app/magisk.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        )
        for (path in paths) {
            if (File(path).exists()) return true
        }

        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true
        }

        var process: Process? = null
        try {
            process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            if (reader.readLine() != null) {
                return true
            }
        } catch (e: Exception) {
            // Safe
        } finally {
            process?.destroy()
        }

        return false
    }

    fun isFridaDetected(): Boolean {
        try {
            System.loadLibrary("frida-agent")
            return true
        } catch (e: UnsatisfiedLinkError) {
            // Normal behavior of throwing when library is absent
        } catch (e: Exception) {
            return true
        }

        try {
            val mapsFile = File("/proc/self/maps")
            if (mapsFile.exists()) {
                mapsFile.bufferedReader().use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        if (line?.contains("frida", ignoreCase = true) == true) {
                            return true
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Checking Frida file maps read failed: ${e.message}")
        }
        return false
    }

    fun isXposedDetected(): Boolean {
        try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            return true
        } catch (e: ClassNotFoundException) {
            // Safe
        }

        try {
            throw Exception("Xposed check")
        } catch (e: Exception) {
            for (element in e.stackTrace) {
                if (element.className.contains("de.robv.android.xposed.installer") ||
                        element.className.contains("de.robv.android.xposed")) {
                    return true
                }
            }
        }
        return false
    }

    fun checkAndWarn(context: Context): Boolean {
        val reasons = mutableListOf<String>()
        if (isEmulator()) reasons.add("محاكي أندرويد (Emulator)")
        if (isRooted()) reasons.add("صلاحيات جيلبريك / روت (Root)")
        if (isFridaDetected()) reasons.add("أداة التلاعب والديناميكية Frida")
        if (isXposedDetected()) reasons.add("إطار العمل Xposed Framework")

        if (reasons.isNotEmpty()) {
            if (context is android.app.Activity) {
                context.runOnUiThread {
                    val message = "تنبيه أمني عالي الخطورة ⚠️\n\n" +
                            "لقد رصد الدرع الصامت بيئة تشغيل غير آمنة أو خاضعة للتحليل والتفكيك:\n\n" +
                            reasons.joinToString("\n") { "⬅️ $it" } + "\n\n" +
                            "التطبيق يرمز لـ 'الدرع الصامت' وقد لا يعمل لحماية ملفاتك وقنوات اتصال الـ VPN بشكل آمن في هذه البيئة."

                    android.app.AlertDialog.Builder(context)
                        .setTitle("⚠️ كشف بيئة معادية!")
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton("متابعة على مسؤوليتي") { dialog, _ ->
                            dialog.dismiss()
                        }
                        .setNegativeButton("إغلاق التطبيق") { _, _ ->
                            context.finishAffinity()
                            System.exit(0)
                        }
                        .show()
                }
            }
            return true
        }
        return false
    }
}
