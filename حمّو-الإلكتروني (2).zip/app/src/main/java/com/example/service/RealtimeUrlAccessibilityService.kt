package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.MainActivity
import java.util.regex.Pattern

class RealtimeUrlAccessibilityService : AccessibilityService() {

    private val urlPattern = Pattern.compile(
        "(https?://|www\\.)[a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-A-Za-z0-9+&@#/%=~_|]"
    )

    private var lastAnalyzedUrl: String = ""
    private var lastAnalyzedTime: Long = 0

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val rootNode = rootInActiveWindow ?: return
        scanForUrls(rootNode)
    }

    private fun scanForUrls(node: AccessibilityNodeInfo?) {
        if (node == null) return

        // Scan current node Text
        node.text?.let { text ->
            val matcher = urlPattern.matcher(text.toString())
            if (matcher.find()) {
                val matchedUrl = matcher.group()
                val currentTime = System.currentTimeMillis()
                // Throttling scans for the same URL in short bursts (3 seconds)
                if (matchedUrl != lastAnalyzedUrl || (currentTime - lastAnalyzedTime) > 3000) {
                    lastAnalyzedUrl = matchedUrl
                    lastAnalyzedTime = currentTime
                    Log.d("AccessibilityShield", "Owasp detected raw url on screen: $matchedUrl")
                    triggerRealtimeScan(matchedUrl)
                }
            }
        }

        // Iterate through children
        for (i in 0 until node.childCount) {
            scanForUrls(node.getChild(i))
        }
    }

    private fun triggerRealtimeScan(url: String) {
        // Broadcast or start main task with this intercept
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("INTERCEPTED_URL_KEY", url)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {
        Log.e("AccessibilityShield", "Accessibility service was interrupted!")
    }
}
