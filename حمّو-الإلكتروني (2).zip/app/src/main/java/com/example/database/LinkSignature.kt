package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "LinkSignature")
data class LinkSignature(
    @PrimaryKey val urlPattern: String,
    val threatType: String, // e.g., PHISHING, MALICIOUS, ZERO_CLICK_EXPLOIT
    val severity: String,   // e.g., HIGH, CRITICAL, MEDIUM, LOW
    val addedDate: Long = System.currentTimeMillis()
)
