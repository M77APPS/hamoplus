package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppPermissionInfo

@Composable
fun PermissionScreenContent(
    context: Context,
    isScanningPermissions: Boolean,
    sensitiveAppList: List<AppPermissionInfo>,
    onTriggerPermissionScan: () -> Unit
) {
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Descriptive Header card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "منظم ومستكشف الصلاحيات الحساسة 🔍",
                    color = neonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "بعض التطبيقات ممكن تسجل صوتك أو تصورك من غير ما تدرى بالخلفية! الدرع الصامت بيكشف جميع التطبيقات غير التابعة للنظام التي تملك حق الوصول للكاميرا، الميكروفون، أو الـ GPS، وبيديك طريق مباشر لإلغائها.",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Trigger scan action card
        Button(
            onClick = onTriggerPermissionScan,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
            shape = RoundedCornerShape(10.dp),
            enabled = !isScanningPermissions
        ) {
            if (isScanningPermissions) {
                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
            } else {
                Text("🔍 جرد الصلاحيات النشطة الآن سلوكياً", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
        }

        // Animated Scanning Bar
        if (isScanningPermissions) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CircularProgressIndicator(color = neonCyan, modifier = Modifier.size(40.dp))
                    Text("جاري استلام حزم بيانات PackageManager وفحص الإذونات...", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }

        // Sensitive apps list
        Text(
            text = "تطبيقات مهدِدة تملك إذونات كاميرا/مايكروفون/GPS (${sensitiveAppList.size})",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth()
        )

        if (sensitiveAppList.isEmpty()) {
            Text(
                text = "لم يتم العثور على تطبيقات غير نظامية تملك صلاحيات خطيرة. جهازك آمن جداً!",
                color = Color.Gray,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(24.dp)
            )
        } else {
            sensitiveAppList.forEach { app ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = glassCardBg),
                    border = BorderStroke(1.dp, glassBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(app.appName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(app.packageName, color = Color.Gray, fontSize = 10.sp)
                            }

                            Button(
                                onClick = {
                                    try {
                                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                            data = Uri.parse("package:${app.packageName}")
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        try {
                                            val intent = Intent(Settings.ACTION_SETTINGS)
                                            context.startActivity(intent)
                                        } catch (x: Exception) {
                                            Toast.makeText(context, "فشل فتح إعدادات النظام للتطبيق", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("إلغاء الصلاحية", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Badges indicator
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (app.hasCamera) {
                                PermissionBadge(label = "كاميرا 📸", color = neonRed)
                            }
                            if (app.hasMic) {
                                PermissionBadge(label = "مايكروفون 🎙️", color = neonRed)
                            }
                            if (app.hasLocation) {
                                PermissionBadge(label = "موقع GPS 📍", color = neonGreen)
                            }
                            if (app.hasContacts) {
                                PermissionBadge(label = "جهات الاتصال 👥", color = neonCyan)
                            }
                            if (app.hasSms) {
                                PermissionBadge(label = "رسائل SMS ✉️", color = neonCyan)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionBadge(label: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
            .border(0.5.dp, color.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Black)
    }
}
