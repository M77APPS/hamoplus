package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LinkScanResult
import com.example.data.ThreatLog

@Composable
fun LinkScannerScreenContent(
    context: Context,
    isScanning: Boolean,
    currentScanResult: LinkScanResult?,
    threatLogs: List<ThreatLog>,
    onExecuteUrlScan: (String) -> Unit
) {
    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    var manualUrlInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explanatory note
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "فحص الروابط المشبوهة يدوياً 🔍",
                    color = neonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "انسخ أي لينك جالك على المحادثات وحطه هنا فوراً قبل ما تفتحه بالمتصفح، الدرع الصامت هيحلله سلوكياً ويكشف إذا كان تنزيل APK تلقامائي أو صفحة تصيد لحساباتك.",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Input and action button
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, glassBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = manualUrlInput,
                    onValueChange = { manualUrlInput = it },
                    label = { Text("أدخل أو الصق الرابط هنا للفحص") },
                    placeholder = { Text("https://example-phishing-link.com") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = neonGreen,
                        unfocusedBorderColor = glassBorder,
                        focusedLabelColor = neonGreen
                    ),
                    singleLine = true
                )

                Button(
                    onClick = {
                        if (manualUrlInput.isBlank()) {
                            Toast.makeText(context, "الرجاء كشط أو إدخال اللينك أولاً يا بطل!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onExecuteUrlScan(manualUrlInput)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                    shape = RoundedCornerShape(10.dp),
                    enabled = !isScanning
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                    } else {
                        Text("🛡️ بدء فحص الرابط سلوكياً وعبر API", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                }
            }
        }

        // Animated Loader circle
        if (isScanning) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(color = neonGreen, modifier = Modifier.size(44.dp))
                    Text(
                        text = "جاري الاتصال وإجراء فحص الـ HEAD السلوكي وعزل الكومبوننت...",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Results Section
        currentScanResult?.let { result ->
            val isSafe = result.riskType == "SAFE"
            val stateColor = if (isSafe) neonGreen else if (result.riskType == "SUSPICIOUS") neonCyan else neonRed

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(2.dp, stateColor)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (isSafe) "🛡️ هذا الرابط نظيف وآمن للاستخدام" else "⚠️ تحذير: تم كشف سلوك خطير أو معادي!",
                        color = stateColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Divider(color = glassBorder, thickness = 1.dp)

                    // Results categories grid details
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ResultDetailRow(label = "مستوى الخطورة الإجمالي:", value = "${result.score}% (risk index)", color = stateColor)
                        ResultDetailRow(label = "نوع التهديد السلوكي:", value = result.threatCategory, color = Color.White)
                        ResultDetailRow(label = "فحص الفهرس السحابي:", value = result.googleSafeBrowsingStatus, color = if (result.googleSafeBrowsingStatus.contains("FLAGGED")) neonRed else neonGreen)
                        ResultDetailRow(label = "محركات الفحص المزدوجة:", value = result.virusTotalDetections, color = Color.White)
                        ResultDetailRow(label = "تتبع مسار التحويلات:", value = result.behavioralRedirection, color = neonCyan)
                        ResultDetailRow(label = "نوع محتوى الصفحة (Header):", value = result.behavioralContentType, color = Color.LightGray)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = result.summary,
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    )
                }
            }
        }

        // Threat Log List Header
        if (threatLogs.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سجل التهديدات والروابط المفحوصة مؤخراً 📝",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "عدد السجلات: ${threatLogs.size}",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                threatLogs.take(15).forEach { log ->
                    val isSafeLog = log.threatType == "SAFE"
                    val itemBorderColor = if (isSafeLog) neonGreen.copy(alpha = 0.15f) else neonRed.copy(alpha = 0.3f)
                    
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = glassCardBg),
                        border = BorderStroke(1.dp, itemBorderColor)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = log.url,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    maxLines = 1,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = log.threatCategory.ifEmpty { "غير محدد" },
                                        fontSize = 10.sp,
                                        color = if (isSafeLog) neonGreen else neonRed,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = log.actionTaken,
                                        fontSize = 9.sp,
                                        color = Color.LightGray
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .background(if (isSafeLog) neonGreen.copy(alpha = 0.1f) else neonRed.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isSafeLog) "مسموح" else "معزول",
                                    color = if (isSafeLog) neonGreen else neonRed,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResultDetailRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = color, fontSize = 11.sp, fontWeight = FontWeight.Black)
    }
}
