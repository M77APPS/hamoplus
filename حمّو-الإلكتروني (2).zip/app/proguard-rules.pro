# Centralized ProGuard Optimization & Obfuscation rules for Hemo Silent Shield

# 1. Attributes preservation for safe execution and reflection
-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod, Exception, SourceFile, LineNumberTable

# 2. Preserve biometric authentication APIs
-keep class androidx.biometric.** { *; }

# 3. Preserve Android services and accessibilities (so optimization doesn't prune them)
-keep public class * extends android.accessibilityservice.AccessibilityService
-keep public class * extends android.service.notification.NotificationListenerService
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# 4. Preserve cryptographic security providers & keys integrations (Keystore components)
-keep class java.security.** { *; }
-keep class javax.crypto.** { *; }
-keep class android.security.** { *; }
-keep class com.example.utils.CryptoUtils { *; }

# 5. Keep Jetpack Compose elements & model classes safe from reflection-based serialization failure
-keepclassmembers class * {
    @androidx.room.Database *;
    @androidx.room.Dao *;
    @androidx.room.Entity *;
}
-keep class com.example.data.** { *; }

# 6. Keep and rename source files attributes safely to hide package paths
-renamesourcefileattribute SourceFile
