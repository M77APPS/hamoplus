package com.example.vault

import java.nio.ByteBuffer
import java.security.InvalidKeyException
import java.security.NoSuchAlgorithmException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.experimental.and

object TotpGenerator {

    private const val TOTP_PERIOD_SEC = 30
    private const val CODE_DIGITS = 6
    private var cachedSecret: String? = null

    /**
     * Retrieves or creates a secure, random seed secret to generate TOTP authenticator values.
     */
    fun getSecretKey(context: android.content.Context): String {
        cachedSecret?.let { return it }
        val prefs = context.getSharedPreferences("hemo_totp_prefs", android.content.Context.MODE_PRIVATE)
        var secret = prefs.getString("totp_secret", null)
        if (secret == null) {
            val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
            val secureRandom = java.security.SecureRandom()
            val sb = StringBuilder()
            for (i in 0 until 16) {
                sb.append(chars[secureRandom.nextInt(chars.length)])
            }
            secret = sb.toString()
            prefs.edit().putString("totp_secret", secret).apply()
        }
        cachedSecret = secret
        return secret
    }

    /**
     * Generates the current active TOTP code using the persistently stored secure secret.
     */
    fun generateCurrentCode(context: android.content.Context): String {
        val secret = getSecretKey(context)
        return generateTotp(secret)
    }

    /**
     * Displays current active TOTP code (providing contextless default fallback compatibility).
     */
    fun generateCurrentCode(): String {
        return generateTotp(cachedSecret ?: "HEMOSILENTSHIELDSECRETKEY")
    }

    private fun decodeBase32(base32: String): ByteArray {
        val clean = base32.uppercase().replace(" ", "")
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        val out = java.io.ByteArrayOutputStream()
        var buffer = 0
        var bitsLeft = 0
        for (c in clean) {
            val idx = chars.indexOf(c)
            if (idx == -1) continue
            buffer = (buffer shl 5) or idx
            bitsLeft += 5
            if (bitsLeft >= 8) {
                out.write((buffer shr (bitsLeft - 8)) and 0xFF)
                bitsLeft -= 8
            }
        }
        val bytes = out.toByteArray()
        return if (bytes.isNotEmpty()) bytes else base32.toByteArray(Charsets.UTF_8)
    }

    /**
     * Generates a 6-digit standard TOTP code for a given secret base string and timestamp.
     */
    fun generateTotp(secret: String, timeMs: Long = System.currentTimeMillis()): String {
        try {
            val keyBytes = decodeBase32(secret)
            val timeIndex = timeMs / 1000 / TOTP_PERIOD_SEC

            val data = ByteBuffer.allocate(8).putLong(timeIndex).array()
            val signKey = SecretKeySpec(keyBytes, "HmacSHA1")
            
            val mac = Mac.getInstance("HmacSHA1")
            mac.init(signKey)
            val hash = mac.doFinal(data)

            // Dynamic Truncation
            val offset = (hash[hash.size - 1] and 0xf).toInt()
            val binary = (
                ((hash[offset].toInt() and 0x7f) shl 24) or
                ((hash[offset + 1].toInt() and 0xff) shl 16) or
                ((hash[offset + 2].toInt() and 0xff) shl 8) or
                (hash[offset + 3].toInt() and 0xff)
            )

            val otp = binary % 1000000
            var otpStr = otp.toString()
            while (otpStr.length < CODE_DIGITS) {
                otpStr = "0$otpStr"
            }
            return otpStr
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: InvalidKeyException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "000000"
    }

    /**
     * Calculates the remaining seconds left in the current 30-second cycle.
     */
    fun getSecondsRemainingInCycle(timeMs: Long = System.currentTimeMillis()): Int {
        val secondsSinceEpoch = timeMs / 1000
        return (TOTP_PERIOD_SEC - (secondsSinceEpoch % TOTP_PERIOD_SEC)).toInt()
    }
}
