package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DeveloperSignatureScreen(
    context: Context,
    onDismissRequested: () -> Unit
) {
    val prefs = remember { context.getSharedPreferences("hemo_prefs", Context.MODE_PRIVATE) }
    var isSubscribed by remember { mutableStateOf(prefs.getBoolean("is_subscribed", false)) }
    var isSoundEnabled by remember { mutableStateOf(prefs.getBoolean("audio_signals", true)) }
    var lastWatchTime by remember { mutableLongStateOf(prefs.getLong("last_watch_time", 0L)) }

    val neonGreen = Color(0xFF00FF41)
    val neonRed = Color(0xFFFE2C55)
    val neonCyan = Color(0xFF00E5FF)
    val glassCardBg = Color(0xFF0C101B)
    val glassBorder = Color(0xFF1E293B)

    // Typewriter effect state
    val signatureText = "حمو الإلكتروني"
    var visibleLettersCount by remember { mutableIntStateOf(0) }
    var displaySignature by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (visibleLettersCount <= signatureText.length) {
            displaySignature = signatureText.take(visibleLettersCount)
            delay(150)
            visibleLettersCount++
        }
    }

    // Daily countdown timer state
    var showWatchCountdown by remember { mutableStateOf(false) }
    var countdownSecondsLeft by remember { mutableIntStateOf(31) }

    LaunchedEffect(showWatchCountdown) {
        if (showWatchCountdown) {
            countdownSecondsLeft = 31
            while (countdownSecondsLeft > 0) {
                delay(1000)
                countdownSecondsLeft--
            }
            // Done watching! Update timestamp
            val currentTimeMillis = System.currentTimeMillis()
            prefs.edit().putLong("last_watch_time", currentTimeMillis).apply()
            lastWatchTime = currentTimeMillis
            showWatchCountdown = false

            // Trigger success sound indicator
            if (isSoundEnabled) {
                try {
                    val toneG = android.media.ToneGenerator(android.media.AudioManager.STREAM_ALARM, 90)
                    toneG.startTone(android.media.ToneGenerator.TONE_CDMA_CONFIRM, 300)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            Toast.makeText(context, "🟢 ممتاز! تم تفعيل وصيانة رخصتك الأمنية لمدة 24 ساعة بمشاهدتك الصادقة لفكر المطور.", Toast.LENGTH_LONG).show()
        }
    }

    // Check if daily video was watched within the last 24 hours
    val isDailyWatchValid = (System.currentTimeMillis() - lastWatchTime) < (24 * 60 * 60 * 1000L)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF06090F))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Custom Cyber Shield Avatar with HAMO signature text
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(neonGreen.copy(alpha = 0.25f), Color.Transparent)))
                .border(2.dp, neonGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "HAMO Shield logo",
                    tint = neonGreen,
                    modifier = Modifier.size(38.dp)
                )
                Text(
                    text = "HAMO",
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }

        // Typewriter title output (Muhammad Hossam / Hamo electronic)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "بصمة المطور العبقري",
                fontSize = 11.sp,
                color = neonCyan,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = displaySignature,
                fontSize = 28.sp,
                color = neonGreen,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "محمد حسام | المبتكر والخبير الأمني المستقل",
                fontSize = 12.sp,
                color = Color.LightGray,
                lineHeight = 16.sp,
                textAlign = TextAlign.Center
            )
        }

        Divider(color = glassBorder, thickness = 1.dp)

        // Interactive Watch Countdown HUD
        if (showWatchCountdown) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF16090A)),
                border = BorderStroke(1.dp, neonRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "جاري تفعيل الدرع... لا تخرج من هذا المعالج",
                        color = neonRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$countdownSecondsLeft",
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "قم بمشاهدة أحدث مقاطع المطور على يوتيوب دعماً له ثم اعد فحص الاتصال.",
                        color = Color.Gray,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Task status list
            Text(
                text = "🔐 مركز المصادقة والترخيص الإجباري",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            // Mission 1: Subscribe YouTube
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(1.dp, if (isSubscribed) neonGreen.copy(alpha = 0.3f) else glassBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "1. اشتراك يوتيوب الإجباري",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "رابط قناة المطور: youtube.com/@hamoelectronic",
                            color = Color.Gray,
                            fontSize = 9.sp
                        )
                    }
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic"))
                                context.startActivity(intent)
                                prefs.edit().putBoolean("is_subscribed", true).apply()
                                isSubscribed = true
                                Toast.makeText(context, "تم تسجيل اشتراكك بنجاح! شكراً لدعمك لحمو.", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "فشل الاتصال بالإنترنت الخارجي", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSubscribed) neonGreen.copy(alpha = 0.2f) else neonCyan),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isSubscribed) "مشترك بنجاح ✓" else "انضم واشترك 🔔",
                            color = if (isSubscribed) neonGreen else Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Mission 2: Watch 31 seconds daily or verify ads
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = glassCardBg),
                border = BorderStroke(1.dp, if (isDailyWatchValid) neonGreen.copy(alpha = 0.3f) else glassBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "2. مشاهدة أحدث فيديو لـ 31 ثانية",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isDailyWatchValid) "حالة الترخيص اليومي: نشط ومفعّل" else "يتطلب تفاعل مدته 31 ثانية يومياً بمحتوى القناة",
                            color = if (isDailyWatchValid) neonGreen else Color.Gray,
                            fontSize = 9.sp
                        )
                    }
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic"))
                                context.startActivity(intent)
                                showWatchCountdown = true
                            } catch (e: Exception) {
                                Toast.makeText(context, "فشل فتح رابط الفيديو", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isDailyWatchValid) neonGreen.copy(alpha = 0.2f) else neonGreen),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isDailyWatchValid) "مكتمل لليوم ✓" else "شاهد وتفاعل 📽️",
                            color = if (isDailyWatchValid) neonGreen else Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Sound Sign toggler card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = glassCardBg.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isSoundEnabled) Icons.Default.Notifications else Icons.Default.Close,
                        contentDescription = "Audio effects",
                        tint = neonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text("البصمة والاهتزاز الصوتي والمؤثرات", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("تمكين أصوات الطنين الكهرومغناطيسي لدرع حمو", color = Color.Gray, fontSize = 8.5.sp)
                    }
                }
                Switch(
                    checked = isSoundEnabled,
                    onCheckedChange = { active ->
                        prefs.edit().putBoolean("audio_signals", active).apply()
                        isSoundEnabled = active
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = neonGreen,
                        checkedTrackColor = neonGreen.copy(alpha = 0.3f)
                    )
                )
            }
        }

        // Proceed Button
        Button(
            onClick = {
                if (!isSubscribed) {
                    Toast.makeText(context, "⚠️ يجب الاشتراك في قناة حمو الإلكتروني وتفعيل الجرس للمتابعة والوصول لميزات التطبيق", Toast.LENGTH_LONG).show()
                } else if (!isDailyWatchValid) {
                    Toast.makeText(context, "⚠️ يرجى التفاعل اليومي بمشاهدة 31 ثانية من احدث فيديو على يوتيوب حمو لتشغيل الخدمة", Toast.LENGTH_LONG).show()
                } else {
                    onDismissRequested()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (isSubscribed && isDailyWatchValid) neonGreen else Color.Gray),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "دخول للوحة التحكم السيبرانية 🛡️",
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 12.5.sp
            )
        }

        // Small Author signature footer
        Text(
            text = "حمو الإلكتروني | خبير أمان معتمد | حماية بلا حدود",
            color = Color.Gray.copy(alpha = 0.8f),
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 10.dp)
        )
    }
}
