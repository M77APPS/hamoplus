package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ThreatLog
import com.example.vault.EncryptionManager
import com.example.vault.TotpGenerator

@Composable
fun EducationalLabScreenContent(
    context: Context,
    logs: List<ThreatLog>,
    vaultSize: Int,
    onSimulateActionTriggered: (String) -> Unit = {}
) {
    val neonGreen = Color(0xFF00FF41)
    val neonCyan = Color(0xFF00E5FF)
    val neonRed = Color(0xFFFE2C55)
    val glassCardBg = Color(0xFF0F1524)
    val glassBorder = Color(0xFF1E293B)

    var currentLabTab by remember { mutableStateOf("phishing") }

    // Achievements state loaded from SharedPreferences
    val prefs = remember { context.getSharedPreferences("hemo_achievements_prefs", Context.MODE_PRIVATE) }
    var simCount by remember { mutableStateOf(prefs.getInt("simulations_run", 0)) }

    // Aggregate requirements for achievements
    val hasFirstScan = logs.isNotEmpty()
    val hasFirstBlock = logs.any { it.threatType != "SAFE" }
    val hasVaultSecret = vaultSize > 0
    val hasSimulated = simCount > 0

    // Update achievement status
    LaunchedEffect(logs.size, vaultSize, simCount) {
        prefs.edit().apply {
            putBoolean("has_first_scan", hasFirstScan)
            putBoolean("has_first_block", hasFirstBlock)
            putBoolean("has_vault_secret", hasVaultSecret)
            putBoolean("has_simulated", hasSimulated)
            apply()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Welcome and Intro
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = glassCardBg),
            border = BorderStroke(1.dp, neonCyan.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Build, contentDescription = "Lab icon", tint = neonCyan, modifier = Modifier.size(24.dp))
                    Text(
                        text = "مختبر حمو الإلكتروني التعليمي 🧪",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "بيئة تجريبية ذكية وآمنة 100% لفهم آليات الهجوم السيبراني وتجربة الدروع الدفاعية سلوكياً.",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    textAlign = TextAlign.Justify
                )
            }
        }

        // Strict warning box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(neonRed.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
                .border(1.5.dp, neonRed.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .padding(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Warning, contentDescription = "Warning", tint = neonRed, modifier = Modifier.size(20.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "⚠️ بيان إخلاء مسؤولية وتحذير فوري:",
                        color = neonRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "جميع الأنشطة والهجومات في هذا المختبر تتم بشكل محاكى ومحلي بالكامل داخل ذاكرة الرام محلياً ولا تجري أي تواصل خارجي حقيقي بإنرنت أو سيرفرات ضارة. تم تصميم هذا القسم من قبل حمّو للتوعية الأمنية وحماية المستخدمين من الوقوع في فخاخ الاختراق فقط.",
                        color = Color.White,
                        fontSize = 9.5.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        // Achievement system
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
            border = BorderStroke(1.dp, neonGreen.copy(alpha = 0.25f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "🎖️ نظام الإنجازات السيبرانية لحمو الإلكتروني",
                    color = neonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Achievement 1: First Scan
                    AchievementBadge(
                        title = "بطل الكاميرات",
                        desc = "أول فحص رابط",
                        isUnlocked = hasFirstScan,
                        modifier = Modifier.weight(1f)
                    )
                    // Achievement 2: First Block
                    AchievementBadge(
                        title = "الدرع الحقيقي",
                        desc = "أول حظر تصيد",
                        isUnlocked = hasFirstBlock,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Achievement 3: Secret stored
                    AchievementBadge(
                        title = "خزانة الحديد",
                        desc = "حفظ سر مشفر",
                        isUnlocked = hasVaultSecret,
                        modifier = Modifier.weight(1f)
                    )
                    // Achievement 4: Lab simulator run
                    AchievementBadge(
                        title = "عقل الهكر",
                        desc = "إجراء محاكاة بالمختبر",
                        isUnlocked = hasSimulated,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Simulator Navigation
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F1422), RoundedCornerShape(10.dp))
                .border(1.dp, glassBorder, RoundedCornerShape(10.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (currentLabTab == "phishing") neonGreen.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { currentLabTab = "phishing" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Phishing 🎣",
                    color = if (currentLabTab == "phishing") neonGreen else Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (currentLabTab == "zeroclick") neonCyan.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { currentLabTab = "zeroclick" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Zero-Click ⚡",
                    color = if (currentLabTab == "zeroclick") neonCyan else Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (currentLabTab == "aes") neonGreen.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { currentLabTab = "aes" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Hardware Crypt 🔑",
                    color = if (currentLabTab == "aes") neonGreen else Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Tab contents
        when (currentLabTab) {
            "phishing" -> {
                PhishingSimulatorCard(
                    onSimulate = { url ->
                        simCount++
                        prefs.edit().putInt("simulations_run", simCount).apply()
                        onSimulateActionTriggered(url)
                    }
                )
            }
            "zeroclick" -> {
                ZeroClickSimulatorCard(
                    onSimulate = { url ->
                        simCount++
                        prefs.edit().putInt("simulations_run", simCount).apply()
                        onSimulateActionTriggered(url)
                    }
                )
            }
            "aes" -> {
                AesHardwareSimulatorCard(
                    context = context,
                    onLockSuccessful = {
                        simCount++
                        prefs.edit().putInt("simulations_run", simCount).apply()
                    }
                )
            }
        }
    }
}

@Composable
fun AchievementBadge(
    title: String,
    desc: String,
    isUnlocked: Boolean,
    modifier: Modifier = Modifier
) {
    val neonGreen = Color(0xFF00FF41)
    val containerBg = if (isUnlocked) Color(0xFF091F11) else Color(0xFF161B22)
    val borderColor = if (isUnlocked) neonGreen.copy(alpha = 0.5f) else Color.DarkGray

    Row(
        modifier = modifier
            .background(containerBg, RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isUnlocked) Icons.Default.CheckCircle else Icons.Default.Lock,
            contentDescription = "Achievement status",
            tint = if (isUnlocked) neonGreen else Color.Gray,
            modifier = Modifier.size(16.dp)
        )
        Column {
            Text(
                text = title,
                color = if (isUnlocked) Color.White else Color.Gray,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = desc,
                color = Color.Gray,
                fontSize = 8.5.sp
            )
        }
    }
}

@Composable
fun PhishingSimulatorCard(onSimulate: (String) -> Unit) {
    val neonGreen = Color(0xFF00FF41)
    val neonCyan = Color(0xFF00E5FF)
    var testDomain by remember { mutableStateOf("https://pay-safe-egypt.com/login") }
    var simulationOutput by remember { mutableStateOf<String?>(null) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1524))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "🎣 محاكي هجوم التصيد (Phishing)",
                color = neonGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = "يقوم المخترق بصناعة رابط يوهم الضحية بأنه حقيقي لسرقة حسابه البنكي أو فيسبوك. ندخل بالأسفل رابطاً مشتبهاً لنرى كيف يصطاده الفحص السلوكي لحمو:",
                color = Color.LightGray,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )

            OutlinedTextField(
                value = testDomain,
                onValueChange = { testDomain = it },
                label = { Text("رابط التصيد المحاكى", fontSize = 10.sp, color = neonGreen) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = neonGreen,
                    unfocusedBorderColor = Color.DarkGray
                ),
                singleLine = true
            )

            Button(
                onClick = {
                    simulationOutput = "🔄 جاري محاكاة الهجوم الهادئ...\n" +
                            "🤖 محاولة الاتصال بالصفحة...\n" +
                            "🔍 فحص السلوك الداخلي لكلمات المفاتيح: [login, signin, secure, banking]\n" +
                            "🚨 تم اكتشاف سلوك التصيد! الرابط يحوي كلمة مريبة ويحاول طلب بيانات حساسة."
                    onSimulate(testDomain)
                },
                colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("بدء تشغيل المحاكاة السيبرانية 🦾", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }

            AnimatedVisibility(visible = simulationOutput != null) {
                simulationOutput?.let { out ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(8.dp))
                            .border(1.dp, neonGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = out,
                            color = neonGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp,
                            lineHeight = 15.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ZeroClickSimulatorCard(onSimulate: (String) -> Unit) {
    val neonCyan = Color(0xFF00E5FF)
    val neonRed = Color(0xFFFE2C55)
    var suspiciousCommand by remember { mutableStateOf("https://malicious.org/download.php?cmd=rm -rf /") }
    var simulationOutput by remember { mutableStateOf<String?>(null) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1524))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "⚡ محاكي اختراق ذو نقرة صفرية (Zero-Click)",
                color = neonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = "يقصد به ثغرات لا تتطلب من الضحية تفاعلاً، بل بمجرد تحميل الرابط بالخلفية يتم تنفيذ الأوامر. نكتب أمراً برمجياً خبيثاً في الرابط لفحصه:",
                color = Color.LightGray,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )

            OutlinedTextField(
                value = suspiciousCommand,
                onValueChange = { suspiciousCommand = it },
                label = { Text("أمر حقن الأكواد المشبوه", fontSize = 10.sp, color = neonCyan) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = neonCyan,
                    unfocusedBorderColor = Color.DarkGray
                ),
                singleLine = true
            )

            Button(
                onClick = {
                    simulationOutput = "⚡ تهيئة الهجوم الصامت لثغرة Zero-Click...\n" +
                            "🔍 جاري إجراء الفحص الهيكلي العميق لمسار URL الخارجي...\n" +
                            "🚨 عثرنا على تطابق نمط الحقن (Command Injection): [cmd, /etc/, file, power, sh]\n" +
                            "❌ تم حظر وعزل الاتصال بالمرجع الأمني لحرق تشغيل الاكسبلويت!"
                    onSimulate(suspiciousCommand)
                },
                colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تشغيل محاكاة الاختراق التجريبي 🦾", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }

            AnimatedVisibility(visible = simulationOutput != null) {
                simulationOutput?.let { out ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(8.dp))
                            .border(1.dp, neonCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = out,
                            color = neonCyan,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp,
                            lineHeight = 15.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AesHardwareSimulatorCard(
    context: Context,
    onLockSuccessful: () -> Unit
) {
    val neonGreen = Color(0xFF00FF41)
    val neonCyan = Color(0xFF00E5FF)
    
    var plaintextToCrypt by remember { mutableStateOf("حمو الإلكتروني بطل الأمان السيبراني!") }
    var encryptedBase64 by remember { mutableStateOf("") }
    var decryptedOutput by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1524))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "🔑 معمل تشفير Keystore مع AES-256-GCM",
                color = neonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = "أدخل أي نص لتشفيره باستخدام مفتاح مادي يتولد داخل الشريحة الأمنية للجهاز (Android Keystore) باستخدام لوغاريتمية AES الرهيبة:",
                color = Color.LightGray,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )

            OutlinedTextField(
                value = plaintextToCrypt,
                onValueChange = { plaintextToCrypt = it },
                label = { Text("النص السري المراد تأمينه", fontSize = 10.sp, color = neonCyan) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = neonCyan,
                    unfocusedBorderColor = Color.DarkGray
                ),
                singleLine = true
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (plaintextToCrypt.isBlank()) {
                            Toast.makeText(context, "الرجاء كتاية نص أولاً للتشفير", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val enc = EncryptionManager.encrypt(plaintextToCrypt)
                            encryptedBase64 = enc
                            decryptedOutput = ""
                            onLockSuccessful()
                            Toast.makeText(context, "تم التشفير بالشريحة المادية! 🔐", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "فشل التشفير: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonGreen),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("قفل وتشفير 🔐", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        if (encryptedBase64.isBlank()) {
                            Toast.makeText(context, "لا توجد بيانات مشفرة مسجلة بعد!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val dec = EncryptionManager.decrypt(encryptedBase64)
                            decryptedOutput = dec
                            Toast.makeText(context, "تم التفكيك بالخوارزمية! 🔓", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "فشل فك التشفير: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("فك التشفير 🔓", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (encryptedBase64.isNotEmpty()) {
                Text("النص المشفر بالبايتات (Base64):", fontSize = 9.5.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = encryptedBase64,
                        color = Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        maxLines = 4,
                        lineHeight = 12.sp
                    )
                }
            }

            if (decryptedOutput.isNotEmpty()) {
                Text("النص بعد التفكيك وفك التشفير الآمن:", fontSize = 9.5.sp, color = neonGreen, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF031609), RoundedCornerShape(8.dp))
                        .border(1.dp, neonGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = decryptedOutput,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
